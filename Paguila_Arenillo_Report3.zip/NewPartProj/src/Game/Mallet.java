package Game;
public class Mallet{
//	private float area;
//	private int xcor;
//	private int ycor;
//	private int length;
//	private int width;
//
//	public Mallet(){
//		this.area = 25;
//		this.xcor = 5;
//		this.ycor = 5;
//		this.length = 5;
//		this.width = 5;}
//	
//	protected void hit(Hole hole){
//		hole.hit();
//	}
}